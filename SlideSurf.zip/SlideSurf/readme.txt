In order to work correctly, one must have the phone and PC connected using native software.

When you're ready to connect the application, run slidesurf.exe and connect through the android app. Go to the presentation screen, select 'Begin Presentation' on the app and you're ready to go!